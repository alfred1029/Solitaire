# ENGG1340 project group 69
## To do list

1. Deck initialization  (Random init, Import Winnable Deck) 
  - Random init  
  - Import Winnable Deck
2. GUI (Ncurses.h)
  - Added guiTemp.cpp for testing purpose
  - To be implement: Offical GUI
3. Check valid input  (For current GUI - DONE)
4. Card Movement  DONE
  - column to column  
  - column to stack  
  - deck to column  
  - deck to stack  
5. undo redo (undo redo done)
6. Save load  
7. File input output  
8. Check win/ no more available move  (Ally)  
9. Leaderboard  
10. Score  


## Game description
## Game rules
## Game features
## Used C/C++ library list
## Compilation and execution instruction
## Group members
Cheung Yan Shek, UID: 3036065575, Github username: namelessxxv

Hong Hiu Shun, UID: 3036065422  

Hui Lok Samuel, UID: 3036059980, Github username: creampithon

Wong Wai Chung, UID: 3036068618, Github username: alfred1029

Wun Ally Lok Yin, UID: 3036068589, Github username: allywun

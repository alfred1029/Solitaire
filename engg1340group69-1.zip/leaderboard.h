#ifndef LEADERBOARD_H
#define LEADERBOARD_H

#include "card.h"
#include <fstream>
#include <vector>
#include <algorithm>

using namespace std;

void leaderboard(Ptr &p);

#endif
